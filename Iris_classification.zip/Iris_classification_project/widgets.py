import streamlit as st
import pandas as pd
st.title("Streamlit Text input")
name=st.text_input("Enter your name:")
if name:
    st.write(f"Hello, {name}")
age=st.slider("Select your age:",0,100,20)
st.write(f"Your age is {age}.")

options=["Python","Java","C++","Javascript","Power BI","DJango"]
choice=st.selectbox("Choose your favorite language:",options)
st.write(f"You selected {choice}.")



data={
    "Name":["John","Jane","Jake","Jill"],
    "Age":[28,24,35,40],
    "City":["New York","Los Angeles","Chicago","Houston"]
}
df=pd.DataFrame(data)
df.to_csv("sampledata.csv")
st.write(df)

uploaded_file=st.file_uploader("choose a csv file", type="csv")

if uploaded_file is not None:
    df=pd.read_csv(uploaded_file)
    st.write(df)
